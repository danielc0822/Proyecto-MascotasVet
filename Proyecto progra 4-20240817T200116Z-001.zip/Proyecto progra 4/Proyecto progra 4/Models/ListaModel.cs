﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Proyecto_progra_4.Models { 

        public class ListaModel
        {
            public int IdPaciente { get; set; }
            public string NombrePaciente{ get; set; }
        }
    }
